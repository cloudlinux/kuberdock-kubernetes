// flocker package allows you to easily interact with a Flocker Control Service.
package flocker
