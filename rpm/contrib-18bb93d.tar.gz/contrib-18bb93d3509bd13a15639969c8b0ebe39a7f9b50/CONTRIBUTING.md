# How to become a contributor and submit your own code

For instructions on how to contribute to the Kubernetes project please refer to the official [contributing guide](https://releases.k8s.io/HEAD/CONTRIBUTING.md)
