# Contributing to SpdyStream

Want to hack on spdystream? Awesome! Here are instructions to get you
started.

SpdyStream is a part of the [Docker](https://docker.io) project, and follows
the same rules and principles. If you're already familiar with the way
Docker does things, you'll feel right at home.

Otherwise, go read
[Docker's contributions guidelines](https://github.com/dotcloud/docker/blob/master/CONTRIBUTING.md).

Happy hacking!
