# WARNING

The API defined here is proposed, experimental, and (for now) subject to change at any time.

**Do not use it.**

If you think you want to use it, or for any other queries, contact <rkt-dev@googlegroups.com> or file an [issue](https://github.com/coreos/rkt/issues/new)

For more information, see:
- #1208
- #1359
- #1468
